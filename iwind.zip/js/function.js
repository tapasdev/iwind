$('#right-arrow').click(function() {
	var currentSlide
})